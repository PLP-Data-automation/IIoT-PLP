# IIoT-PLP
Python modulefor IIoT integration with Power BI
