# DataBase
Python-based data storing tool for IIoT application
