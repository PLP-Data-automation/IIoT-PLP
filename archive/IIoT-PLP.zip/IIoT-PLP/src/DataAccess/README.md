# DataAccess
Python-based fetching engine for ewon IIoT devices.
