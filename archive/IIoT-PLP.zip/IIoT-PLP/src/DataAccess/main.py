from DataAccess.Query import run_query

df = run_query( "full-filter" )
print( df )